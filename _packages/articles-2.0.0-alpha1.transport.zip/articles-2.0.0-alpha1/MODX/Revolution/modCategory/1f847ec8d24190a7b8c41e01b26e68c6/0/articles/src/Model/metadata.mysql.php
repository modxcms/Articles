<?php

$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Articles\\Model',
    'namespacePrefix' => 'Articles',
    'class_map' =>
    array (
        'MODX\\Revolution\\modResource' =>
        array (
            0 => 'Articles\\Model\\ArticlesContainer',
            1 => 'Articles\\Model\\Article',
        )
    ),
);