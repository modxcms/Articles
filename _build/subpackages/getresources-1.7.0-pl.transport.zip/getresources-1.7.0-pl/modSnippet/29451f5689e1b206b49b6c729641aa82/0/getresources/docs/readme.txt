--------------------
Snippet: getResources
--------------------
Version: 1.7.0-pl
Released: April 29, 2021
Since: December 28, 2009
Author: Jason Coward <jason@opengeek.com>

A general purpose Resource listing and summarization snippet for MODX Revolution.

Official Documentation:
https://docs.modx.com/current/en/extras/getresources
